using System.Collections.Generic;
using System.Linq;
using System.Text;
using Varigence.Biml.Extensions;
using Varigence.Languages.Biml.Table; // this is necessary to make the code work
public static class HelperClass
{
    public static int NumberOfColumns(AstTableNode node)
    {
        return node.Columns.Count;
    }
}