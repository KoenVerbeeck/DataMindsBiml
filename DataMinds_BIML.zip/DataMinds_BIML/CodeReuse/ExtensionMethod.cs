using System.Collections.Generic;
using System.Linq;
using System.Text;
using Varigence.Biml.Extensions;
using Varigence.Languages.Biml;
using Varigence.Languages.Biml.Table;

public static class HelperClass
{
    public static int NumberOfColumns(this AstTableNode node)
    {
        return node.Columns.Count;
    }
}